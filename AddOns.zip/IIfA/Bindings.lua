-- this puts the item in the bind list, toggle call is in bindings.xml
ZO_CreateStringId("SI_BINDING_NAME_TOGGLE_INVENTORY_FRAME", "Toggle Inventory Frame")

