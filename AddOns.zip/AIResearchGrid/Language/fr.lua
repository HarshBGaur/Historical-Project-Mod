﻿--[[
	FR Language file, made by Ayantir
]]

SafeAddString(AIRG_OPTIONS_RELATIVE					, "Voir pour :", 1)
SafeAddString(AIRG_OPTIONS_RELATIVE_TO				, "|c4AFF6EVoir :|r", 1)
SafeAddString(AIRG_OPTIONS_ALL						, "#TOUS", 1)
SafeAddString(AIRG_KEYBIND_TOGGLE					, "Afficher/Masquer AI Research Grid", 1)