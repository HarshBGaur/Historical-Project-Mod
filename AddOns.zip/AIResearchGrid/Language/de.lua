﻿--[[
	DE Language file, made by Baertram
]]

SafeAddString(AIRG_OPTIONS_RELATIVE					, "Positioniere relativ zu :", 1)
SafeAddString(AIRG_OPTIONS_RELATIVE_TO				, "|c4AFF6ERelativ zu :|r", 1)
SafeAddString(AIRG_OPTIONS_ALL						, "#ALLE", 1)